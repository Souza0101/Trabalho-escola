import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        LabelFrame lf = new LabelFrame();
        lf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        lf.setSize(660,280);
        lf.setVisible(true);
    }
}
